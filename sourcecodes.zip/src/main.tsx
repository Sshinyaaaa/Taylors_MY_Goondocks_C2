import React from "react";
import ReactDOM from "react-dom/client";
import { TideCloakContextProvider } from "@tidecloak/react";
import App from "./App";
import tcConfig from "../public/tidecloak.json";
import "./index.css";

// The provider takes the adapter JSON directly as the config prop.
// useDPoP goes inside the config object, not as a separate JSX prop (I-12).
ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <TideCloakContextProvider
      config={{ ...tcConfig, useDPoP: { mode: "strict", alg: "ES256" } }}
    >
      <App />
    </TideCloakContextProvider>
  </React.StrictMode>
);

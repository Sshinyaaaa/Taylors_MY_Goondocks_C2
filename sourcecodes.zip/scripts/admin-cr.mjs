// Operator helper (master-admin credentials from .env). Read-only by default.
//   node scripts/admin-cr.mjs status            list role holders + pending change requests
//   node scripts/admin-cr.mjs deny <id>         deny a PENDING change request
//   node scripts/admin-cr.mjs make-approver <username>
//        file the governed request granting tide-realm-admin (it still needs enclave approval)
import { readFileSync } from "node:fs";
const env = Object.fromEntries(readFileSync(".env", "utf8").split(/\r?\n/).filter((l) => l.includes("=") && !l.startsWith("#")).map((l) => [l.slice(0, l.indexOf("=")), l.slice(l.indexOf("=") + 1)]));
const TC = env.TIDECLOAK_URL || "http://localhost:8080", REALM = env.TIDECLOAK_REALM || "blindorbit";
const B = `${TC}/admin/realms/${REALM}`;
const tok = async () => (await (await fetch(`${TC}/realms/master/protocol/openid-connect/token`, { method: "POST", body: new URLSearchParams({ grant_type: "password", client_id: "admin-cli", username: env.KC_BOOTSTRAP_ADMIN_USERNAME || "admin", password: env.KC_BOOTSTRAP_ADMIN_PASSWORD }) })).json()).access_token;
const call = async (p, m = "GET", b) => { const r = await fetch(B + p, { method: m, headers: { Authorization: `Bearer ${await tok()}`, "Content-Type": "application/json" }, body: b && JSON.stringify(b) }); const t = await r.text(); let j = t; try { j = t ? JSON.parse(t) : null; } catch {} return { s: r.status, j, loc: r.headers.get("location") }; };
const [cmd, arg] = process.argv.slice(2);
const users = Object.fromEntries((await call("/users")).j.map((u) => [u.id, u.username]));
const rm = (await call("/clients?clientId=realm-management")).j[0];

if (cmd === "deny") {
  const cr = (await call(`/iga/change-requests/${arg}`)).j;
  if (cr?.status !== "PENDING") { console.error(`not PENDING (${cr?.status}); refusing`); process.exit(1); }
  console.log("deny", (await call(`/iga/change-requests/${arg}/deny`, "POST", { reason: "superseded: filed before approver quorum was configured" })).s);
} else if (cmd === "make-approver") {
  const u = (await call(`/users?username=${arg}&exact=true`)).j[0];
  const role = (await call(`/clients/${rm.id}/roles/tide-realm-admin`)).j;
  const r = await call(`/users/${u.id}/role-mappings/clients/${rm.id}`, "POST", [role]);
  console.log(`grant tide-realm-admin -> ${arg}: HTTP ${r.s} ${r.loc ?? ""}`);
}

console.log("tide-realm-admin:", (await call(`/clients/${rm.id}/roles/tide-realm-admin/users`)).j.map((u) => u.username).join(", "));
console.log("conjunction-assessor:", (await call(`/roles/conjunction-assessor/users`)).j.map((u) => u.username).join(", ") || "(nobody)");
for (const c of (await call("/iga/change-requests?status=PENDING")).j || [])
  console.log(`PENDING ${c.id} ${c.actionType} ${users[c.entityId] ?? c.entityType} ${c.authorizationCount}/${c.threshold} by=[${(c.authorizers || []).map((a) => a.username)}]`);
